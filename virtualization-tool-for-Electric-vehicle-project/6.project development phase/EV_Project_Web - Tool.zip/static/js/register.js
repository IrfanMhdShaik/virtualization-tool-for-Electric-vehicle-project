var generatedOTP;

function sendOTP() {
  generatedOTP = Math.floor(1000 + Math.random() * 9000);
  alert("Your OTP is: " + generatedOTP);   // Fake SMS/Email
  document.getElementById("msg").innerHTML = "OTP sent successfully!";
}

function verifyOTP() {
  var userOTP = document.getElementById("otp").value;

  if (userOTP == generatedOTP) {
    document.getElementById("msg").innerHTML = "✅ Verified Successfully! Registration complete.";
  } else {
    document.getElementById("msg").innerHTML = "❌ Invalid OTP. Try again.";
  }
}
